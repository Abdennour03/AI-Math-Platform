class Teacher:
    def __init__(self, teacher_id, full_name, email, password, phone_number):
            self.teacher_id = teacher_id
            self.full_name = full_name
            self.email = email
            self.password = password
            self.phone_number = phone_number
